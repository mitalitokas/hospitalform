package com.example.HospitalForm;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HospitalFormApplicationTests {

	@Test
	void contextLoads() {
	}

}
